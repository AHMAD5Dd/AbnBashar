# Tele User checker
###
just deploy the bot on heroku and start checking the rare users 

### [DEPLOY !!](https://dashboard.heroku.com/new?template=https://github.com/J5J5/for_J5J5) ###

### DEV : [UNKNOWN](https://t.me/K_8_U) ###
